@echo off
cd /d "%~dp0"
start "" pythonw SS_OIL_SMJENE.py
