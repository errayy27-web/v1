@echo off
cd /d "%~dp0"
py -m pip install pyinstaller==6.16.0
py -m PyInstaller --noconfirm --clean --onefile --windowed --name SS_OIL_SMJENE SS_OIL_SMJENE.py
pause
