@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo SS OIL SMJENE - Windows EXE hazirlaniyor...
py -m pip install --upgrade pyinstaller
if errorlevel 1 goto fail
py -m PyInstaller --noconfirm --clean --onefile --windowed --name "SS_OIL_SMJENE" SS_OIL_SMJENE.py
if errorlevel 1 goto fail
echo.
echo EXE hazir: dist\SS_OIL_SMJENE.exe
explorer dist
pause
exit /b 0
:fail
echo HATA: Python 3 ve internet baglantisini kontrol edin.
pause
exit /b 1
