# -*- coding: utf-8 -*-
"""SS OIL — Smjene cash counting. Standard-library-only desktop app."""
import tkinter as tk
from tkinter import ttk, messagebox
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from datetime import date, datetime
from pathlib import Path
import os, sqlite3, json, urllib.request, urllib.error, threading, queue, time

APP_DIR=Path(os.environ.get("LOCALAPPDATA",str(Path.home()))) / "SS_OIL_Smjene_Kasa"
APP_DIR.mkdir(parents=True,exist_ok=True)
DB=APP_DIR/"smjene_kasa.sqlite3"
VALUES=["200","100","50","20","10","5","2","1","0.5","0.2","0.1","0.05"]
ZERO=Decimal("0.00")
RATE=Decimal("1.90")
def money(v):
    return f"{v.quantize(Decimal('0.01'),rounding=ROUND_HALF_UP):.2f}".replace(".",",")
def dec(s):
    s=str(s).strip().replace(" ","").replace(",",".")
    if not s: return ZERO
    try: return Decimal(s)
    except InvalidOperation: return ZERO
def connect():
    con=sqlite3.connect(DB)
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("CREATE TABLE IF NOT EXISTS employees (name TEXT PRIMARY KEY)")
    con.execute("""CREATE TABLE IF NOT EXISTS shifts (
      business_date TEXT NOT NULL, shift INTEGER NOT NULL, employee TEXT NOT NULL DEFAULT '',
      credit TEXT NOT NULL DEFAULT '', euros TEXT NOT NULL DEFAULT '',
      updated_at TEXT NOT NULL, remote_revision INTEGER DEFAULT -1, remote_id TEXT DEFAULT '', synced_total TEXT DEFAULT '', remote_override TEXT DEFAULT '', local_baseline TEXT DEFAULT '', PRIMARY KEY(business_date,shift))""")
    con.execute("""CREATE TABLE IF NOT EXISTS cash_counts (
      business_date TEXT NOT NULL, shift INTEGER NOT NULL, denomination TEXT NOT NULL,
      quantity TEXT NOT NULL DEFAULT '', PRIMARY KEY(business_date,shift,denomination))""")
    cols={r[1] for r in con.execute("PRAGMA table_info(shifts)")}
    for name,kind in [("remote_revision","INTEGER DEFAULT -1"),("remote_id","TEXT DEFAULT ''"),("synced_total","TEXT DEFAULT ''"),("remote_override","TEXT DEFAULT ''"),("local_baseline","TEXT DEFAULT ''")]:
        if name not in cols:con.execute(f"ALTER TABLE shifts ADD COLUMN {name} {kind}")
    con.commit()
    return con

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("SS OIL | Smjene - Novac")
        self.geometry("780x800")
        self.minsize(700,700)
        self.configure(bg="#f3f5f8")
        self.db=connect()
        self.loading=False
        self.day=tk.StringVar(value=date.today().isoformat())
        self.shift=tk.IntVar(value=1)
        self.employee=tk.StringVar()
        self.credit=tk.StringVar()
        self.euros=tk.StringVar()
        self.qty={v:tk.StringVar() for v in VALUES}
        self.row_totals={v:tk.StringVar(value="0,00") for v in VALUES}
        self.cash_total=tk.StringVar(value="0,00 KM")
        self.credit_total=tk.StringVar(value="0,00 KM")
        self.euro_total=tk.StringVar(value="0,00 KM")
        self.all_total=tk.StringVar(value="0,00 KM")
        self.remote_info=tk.StringVar(value="")
        self.status=tk.StringVar(value="Podaci se automatski čuvaju.")
        self.cloud_cfg=APP_DIR/"merkez_ayarlar.json"
        self.cfg=self.read_cfg()
        self.network_events=queue.Queue()
        self.sync_running=False
        self.last_saved={}
        self.after(3000,self.sync_tick)
        self.build()
        for var in list(self.qty.values())+[self.employee,self.credit,self.euros]:
            var.trace_add("write",self.changed)
        self.load()
        self.protocol("WM_DELETE_WINDOW",self.close)
    def build(self):
        style=ttk.Style(self)
        style.theme_use("clam")
        style.configure("TNotebook.Tab",font=("Segoe UI",12,"bold"),padding=(22,12))
        style.configure("TEntry",padding=5)
        outer=tk.Frame(self,bg="#f3f5f8",padx=24,pady=16)
        outer.pack(fill="both",expand=True)
        tk.Label(outer,text="SS OIL  •  SMJENE",font=("Segoe UI",22,"bold"),fg="#162a42",bg="#f3f5f8").pack(anchor="w")
        top=tk.Frame(outer,bg="#f3f5f8")
        top.pack(fill="x",pady=(12,8))
        tk.Label(top,text="Datum (GGGG-MM-DD):",bg="#f3f5f8",font=("Segoe UI",10)).pack(side="left")
        day_entry=ttk.Entry(top,textvariable=self.day,width=15)
        day_entry.pack(side="left",padx=(8,12))
        day_entry.bind("<Return>",lambda e:self.change_day())
        day_entry.bind("<FocusOut>",lambda e:self.change_day())
        ttk.Button(top,text="Otvori datum",command=self.change_day).pack(side="left")
        ttk.Button(top,text="Danas",command=lambda:(self.day.set(date.today().isoformat()),self.change_day())).pack(side="left",padx=8)
        ttk.Button(top,text="Merkez Ayarları",command=self.configure_cloud).pack(side="right")
        self.tabs=ttk.Notebook(outer)
        self.tabs.pack(fill="x",pady=(4,12))
        for n in (1,2,3):
            page=tk.Frame(self.tabs,bg="#ffffff",height=8)
            self.tabs.add(page,text=f"Smjena {n}")
        self.tabs.bind("<<NotebookTabChanged>>",self.change_shift)
        person=tk.Frame(outer,bg="#f3f5f8")
        person.pack(fill="x",pady=(2,12))
        tk.Label(person,text="Radnik / Zaposleni:",font=("Segoe UI",11,"bold"),bg="#f3f5f8").pack(side="left",padx=(0,12))
        self.employee_box=ttk.Combobox(person,textvariable=self.employee,width=34)
        self.employee_box.pack(side="left")
        self.employee_box.bind("<<ComboboxSelected>>",lambda e:self.save())
        ttk.Button(person,text="Sačuvaj ime",command=self.save_employee).pack(side="left",padx=10)
        table=tk.Frame(outer,bg="#ffffff",padx=16,pady=10,highlightbackground="#dfe4ea",highlightthickness=1)
        table.pack(fill="x")
        headings=tk.Frame(table,bg="#e7edf5")
        headings.pack(fill="x")
        for col,text,width in ((0,"NOVAC",18),(1,"KOM",16),(2,"UKUPNO (KM)",22)):
            tk.Label(headings,text=text,width=width,anchor="center",bg="#e7edf5",fg="#142b46",font=("Segoe UI",11,"bold"),pady=8).grid(row=0,column=col)
        for i,value in enumerate(VALUES):
            row=tk.Frame(table,bg="#ffffff")
            row.pack(fill="x",pady=2)
            tk.Label(row,text=value.replace(".",","),width=18,font=("Segoe UI",11),bg="#ffffff",anchor="center").grid(row=0,column=0)
            entry=ttk.Entry(row,textvariable=self.qty[value],width=16,justify="center",font=("Segoe UI",11))
            entry.grid(row=0,column=1,padx=8)
            tk.Label(row,textvariable=self.row_totals[value],width=22,anchor="e",font=("Segoe UI",11),bg="#ffffff").grid(row=0,column=2,padx=6)
        self.summary_row(table,"UKUPNO KEŠ",self.cash_total,bold=True)
        bottom=tk.Frame(outer,bg="#f3f5f8")
        bottom.pack(fill="x",pady=14)
        self.input_row(bottom,"KREDIT KARTICA (KM)",self.credit,self.credit_total)
        self.input_row(bottom,"EURO × 1,90 KM",self.euros,self.euro_total)
        self.summary_row(bottom,"UKUPNO SVE",self.all_total,bold=True)
        tk.Label(outer,textvariable=self.remote_info,bg="#f3f5f8",fg="#173c68",font=("Segoe UI",10,"bold")).pack(anchor="w")
        tk.Label(outer,textvariable=self.status,bg="#f3f5f8",fg="#477252",font=("Segoe UI",9)).pack(anchor="w",pady=5)
        self.refresh_employees()
    def input_row(self,parent,title,var,result):
        row=tk.Frame(parent,bg="#f3f5f8")
        row.pack(fill="x",pady=4)
        tk.Label(row,text=title,width=26,anchor="w",font=("Segoe UI",11,"bold"),bg="#f3f5f8").pack(side="left")
        ttk.Entry(row,textvariable=var,width=18,justify="center").pack(side="left",padx=8)
        tk.Label(row,textvariable=result,font=("Segoe UI",11,"bold"),bg="#f3f5f8",anchor="e").pack(side="right")
    def summary_row(self,parent,title,var,bold=False):
        row=tk.Frame(parent,bg="#e7edf5" if bold else "#ffffff",padx=10,pady=8)
        row.pack(fill="x",pady=(7,0))
        tk.Label(row,text=title,font=("Segoe UI",12,"bold"),bg=row["bg"],fg="#162a42").pack(side="left")
        tk.Label(row,textvariable=var,font=("Segoe UI",13,"bold"),bg=row["bg"],fg="#162a42").pack(side="right")
    def refresh_employees(self):
        self.employee_box["values"]=[r[0] for r in self.db.execute("SELECT name FROM employees ORDER BY name COLLATE NOCASE")]
    def save_employee(self):
        name=self.employee.get().strip()
        if not name:
            messagebox.showwarning("Radnik","Unesite ime radnika.")
            return
        self.db.execute("INSERT OR IGNORE INTO employees(name) VALUES(?)",(name,))
        self.db.commit()
        self.refresh_employees()
        self.save()
    def change_shift(self,event=None):
        new=self.tabs.index(self.tabs.select())+1
        if new!=self.shift.get():
            self.save()
            self.shift.set(new)
            self.load()
    def change_day(self):
        try: datetime.strptime(self.day.get(),"%Y-%m-%d")
        except ValueError:
            messagebox.showerror("Datum","Koristite format GGGG-MM-DD, npr. 2026-10-25.")
            return
        self.load()
    def load(self):
        self.loading=True
        d,n=self.day.get(),self.shift.get()
        rec=self.db.execute("SELECT employee,credit,euros FROM shifts WHERE business_date=? AND shift=?",(d,n)).fetchone()
        self.employee.set(rec[0] if rec else "")
        self.credit.set(rec[1] if rec else "")
        self.euros.set(rec[2] if rec else "")
        quantities=dict(self.db.execute("SELECT denomination,quantity FROM cash_counts WHERE business_date=? AND shift=?",(d,n)).fetchall())
        for v in VALUES:self.qty[v].set(quantities.get(v,""))
        self.loading=False
        self.recalculate()
        self.status.set(f"Datum: {d}  •  Smjena {n}  •  Automatsko čuvanje uključeno")
        self.show_remote_info()
    def changed(self,*args):
        if self.loading:return
        self.recalculate()
        self.save()
    def recalculate(self):
        total=ZERO
        for value in VALUES:
            qty=dec(self.qty[value].get())
            amount=Decimal(value)*qty
            total+=amount
            self.row_totals[value].set(money(amount))
        card=dec(self.credit.get())
        euro=dec(self.euros.get())*RATE
        self.cash_total.set(money(total)+" KM")
        self.credit_total.set(money(card)+" KM")
        self.euro_total.set(money(euro)+" KM")
        self.all_total.set(money(total+card+euro)+" KM")
    def save(self):
        if self.loading:return
        d,n=self.day.get(),self.shift.get()
        try:datetime.strptime(d,"%Y-%m-%d")
        except ValueError:return
        name=self.employee.get().strip()
        now=datetime.now().isoformat(timespec="seconds")
        with self.db:
            self.db.execute("""INSERT INTO shifts(business_date,shift,employee,credit,euros,updated_at)
            VALUES(?,?,?,?,?,?) ON CONFLICT(business_date,shift) DO UPDATE SET
            employee=excluded.employee,credit=excluded.credit,euros=excluded.euros,updated_at=excluded.updated_at""",
            (d,n,name,self.credit.get(),self.euros.get(),now))
            if name:self.db.execute("INSERT OR IGNORE INTO employees(name) VALUES(?)",(name,))
            for value,var in self.qty.items():
                self.db.execute("""INSERT INTO cash_counts(business_date,shift,denomination,quantity)
                VALUES(?,?,?,?) ON CONFLICT(business_date,shift,denomination)
                DO UPDATE SET quantity=excluded.quantity""",(d,n,value,var.get()))
        self.refresh_employees()
    def read_cfg(self):
        try:return json.loads(self.cloud_cfg.read_text(encoding="utf-8"))
        except Exception:return {}
    def configure_cloud(self):
        dialog=tk.Toplevel(self)
        dialog.title("SS OIL Merkez Bağlantısı")
        dialog.geometry("560x330")
        dialog.transient(self)
        labels=[("Supabase URL","url"),("Publishable / anon API key","key"),("Kullanıcı e-posta","email"),("Kullanıcı şifresi","password")]
        vars={}
        for i,(label,key) in enumerate(labels):
            tk.Label(dialog,text=label).grid(row=i,column=0,sticky="w",padx=12,pady=12)
            v=tk.StringVar(value=self.cfg.get(key,""))
            ttk.Entry(dialog,textvariable=v,width=46,show="*" if key=="password" else "").grid(row=i,column=1,padx=10)
            vars[key]=v
        def save_config():
            self.cfg={k:v.get().strip() for k,v in vars.items()}
            self.cloud_cfg.write_text(json.dumps(self.cfg,ensure_ascii=False,indent=2),encoding="utf-8")
            dialog.destroy()
            self.status.set("Merkez ayarları kaydedildi. 3 saniyede bir eşitleme etkin.")
        ttk.Button(dialog,text="Kaydet",command=save_config).grid(row=5,column=1,pady=18)
    def show_remote_info(self):
        rec=self.db.execute("SELECT remote_override FROM shifts WHERE business_date=? AND shift=?",(self.day.get(),self.shift.get())).fetchone()
        if rec and rec[0]:
            self.remote_info.set("Telefondan teslim edilen: "+money(dec(rec[0]))+" KM (PC sayımından farklı)")
        else:self.remote_info.set("")
    def sync_tick(self):
        while True:
            try:kind,payload=self.network_events.get_nowait()
            except queue.Empty:break
            if kind=="status":self.status.set(payload)
            if kind=="remote":
                d,n,total=payload
                if d==self.day.get() and n==self.shift.get():
                    self.show_remote_info()
        if not self.sync_running and self.cfg.get("url") and self.cfg.get("key") and self.cfg.get("email") and self.cfg.get("password"):
            self.sync_running=True
            threading.Thread(target=self.sync_worker,daemon=True).start()
        self.after(3000,self.sync_tick)
    def http_json(self,method,url,headers,data=None):
        payload=json.dumps(data).encode() if data is not None else None
        req=urllib.request.Request(url,data=payload,headers=headers,method=method)
        with urllib.request.urlopen(req,timeout=7) as response:
            body=response.read().decode()
            return json.loads(body) if body else None
    def sync_worker(self):
        # Each worker uses its own SQLite connection; tkinter stays on the main thread.
        con=None
        try:
            cfg=dict(self.cfg)
            root=cfg["url"].rstrip("/")
            base_headers={"apikey":cfg["key"],"Content-Type":"application/json"}
            auth=self.http_json("POST",root+"/auth/v1/token?grant_type=password",base_headers,
                {"email":cfg["email"],"password":cfg["password"]})
            token=auth["access_token"]
            headers={**base_headers,"Authorization":"Bearer "+token,"Prefer":"return=representation"}
            con=sqlite3.connect(DB,timeout=10)
            rows=con.execute("""SELECT business_date,shift,employee,credit,euros,remote_revision,remote_id,synced_total,remote_override,local_baseline
                FROM shifts ORDER BY business_date DESC,shift LIMIT 180""").fetchall()
            for d,n,name,card,euros,rev,rid,synced,override,baseline in rows:
                amounts=con.execute("SELECT denomination,quantity FROM cash_counts WHERE business_date=? AND shift=?",(d,n)).fetchall()
                cash=sum((dec(k)*dec(q) for k,q in amounts),ZERO)
                local_total=(cash+dec(euros)*RATE).quantize(Decimal("0.01"))
                remote_url=root+"/rest/v1/ssoil_shift_handoffs?select=*&business_date=eq."+d+"&shift_number=eq."+str(n)
                remote=self.http_json("GET",remote_url,headers)
                if not remote:
                    # A handoff must be created by S6 first to retain accurate sales snapshots.
                    continue
                record=remote[0]
                remote_total=dec(record.get("delivered_cash"))
                remote_rev=int(record.get("revision") or 0)
                previous=dec(synced) if synced else None
                if previous is None:
                    # Initial link: don't overwrite an existing phone handoff.
                    con.execute("UPDATE shifts SET remote_revision=?,remote_id=?,synced_total=?,remote_override=?,local_baseline=? WHERE business_date=? AND shift=?",
                        (remote_rev,record["id"],str(remote_total),str(remote_total) if remote_total!=local_total else "",str(local_total),d,n))
                    con.commit()
                    self.network_events.put(("remote",(d,n,str(remote_total))))
                    continue
                local_changed=local_total!=dec(baseline)
                remote_changed=remote_total!=previous
                if local_changed and remote_changed:
                    self.network_events.put(("status",f"ÇAKIŞMA: {d} / Smjena {n}. PC ve telefon değişmiş; kayıtlar korunuyor."))
                    continue
                if local_changed:
                    patch_url=root+"/rest/v1/ssoil_shift_handoffs?id=eq."+str(record["id"])+"&revision=eq."+str(remote_rev)
                    patch={ "delivered_cash":float(local_total)}
                    updated=self.http_json("PATCH",patch_url,{**headers,"Prefer":"return=representation"},patch)
                    if updated:
                        record=updated[0]
                        con.execute("UPDATE shifts SET remote_revision=?,remote_id=?,synced_total=?,remote_override='',local_baseline=? WHERE business_date=? AND shift=?",
                            (record.get("revision",remote_rev),record["id"],str(local_total),str(local_total),d,n))
                        con.commit()
                elif remote_changed:
                    con.execute("UPDATE shifts SET remote_revision=?,remote_id=?,synced_total=?,remote_override=?,local_baseline=? WHERE business_date=? AND shift=?",
                        (remote_rev,record["id"],str(remote_total),str(remote_total) if remote_total!=local_total else "",str(local_total),d,n))
                    con.commit()
                    self.network_events.put(("remote",(d,n,str(remote_total))))
                else:
                    con.execute("UPDATE shifts SET remote_revision=?,remote_id=? WHERE business_date=? AND shift=?",(remote_rev,record["id"],d,n))
                    con.commit()
            self.network_events.put(("status","Merkez eşitlendi: "+datetime.now().strftime("%H:%M:%S")+" • 3 saniye"))
        except Exception as e:
            self.network_events.put(("status","Merkez bağlantı hatası (yerel kayıtlar korunuyor): "+str(e)[:130]))
        finally:
            if con:con.close()
            self.sync_running=False
    def close(self):
        self.save()
        self.db.close()
        self.destroy()

if __name__=="__main__":
    App().mainloop()
