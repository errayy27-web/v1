@echo off
cd /d "%~dp0"
py SS_OIL_SMJENE.py
