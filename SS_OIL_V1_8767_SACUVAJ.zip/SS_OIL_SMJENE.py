# -*- coding: utf-8 -*-
"""SS OIL V1 — compact 3-column cash counter. No external dependencies."""
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import date, datetime
from calendar import monthrange, month_name
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path
import sqlite3, os, json, urllib.request, urllib.parse, urllib.error, threading

DENOMS=("200","100","50","20","10","5","2","1","0.5","0.2","0.1","0.05")
RATE=Decimal("1.90")
ROOT=Path(os.environ.get("LOCALAPPDATA",str(Path.home()))) / "SS_OIL_Smjene_Kasa"
ROOT.mkdir(parents=True,exist_ok=True)
DB=ROOT/"smjene_kasa.sqlite3"
def number(s):
    try: return Decimal(str(s).strip().replace(" ","").replace(",",".") or "0")
    except InvalidOperation: return Decimal(0)
def fmt(v):
    return f"{v.quantize(Decimal('.01'),rounding=ROUND_HALF_UP):.2f}".replace(".",",")
def database():
    c=sqlite3.connect(DB)
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("CREATE TABLE IF NOT EXISTS employees (name TEXT PRIMARY KEY)")
    c.execute("""CREATE TABLE IF NOT EXISTS shifts (
      business_date TEXT NOT NULL, shift INTEGER NOT NULL, employee TEXT NOT NULL DEFAULT '',
      credit TEXT NOT NULL DEFAULT '', euros TEXT NOT NULL DEFAULT '',
      updated_at TEXT NOT NULL, remote_revision INTEGER DEFAULT -1, remote_id TEXT DEFAULT '',
      synced_total TEXT DEFAULT '', remote_override TEXT DEFAULT '', local_baseline TEXT DEFAULT '',
      PRIMARY KEY(business_date,shift))""")
    c.execute("""CREATE TABLE IF NOT EXISTS cash_counts (
      business_date TEXT NOT NULL, shift INTEGER NOT NULL, denomination TEXT NOT NULL,
      quantity TEXT NOT NULL DEFAULT '', PRIMARY KEY(business_date,shift,denomination))""")
    c.execute("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY,value TEXT NOT NULL)")
    c.commit()
    return c

class DatePicker(tk.Toplevel):
    def __init__(self,master,initial,callback):
        super().__init__(master)
        self.title("Odaberi datum")
        self.resizable(False,False)
        self.transient(master)
        self.callback=callback
        self.year,self.month=initial.year,initial.month
        self.configure(bg="#f5f7fa")
        head=tk.Frame(self,bg="#f5f7fa",padx=12,pady=8)
        head.pack(fill="x")
        tk.Button(head,text="◀",width=3,command=lambda:self.move(-1)).pack(side="left")
        self.heading=tk.Label(head,bg="#f5f7fa",font=("Segoe UI",11,"bold"),width=19)
        self.heading.pack(side="left")
        tk.Button(head,text="▶",width=3,command=lambda:self.move(1)).pack(side="left")
        self.days=tk.Frame(self,bg="#f5f7fa",padx=12,pady=5)
        self.days.pack()
        ttk.Button(self,text="Danas",command=lambda:self.choose(date.today())).pack(pady=(4,12))
        self.paint()
        self.grab_set()
    def move(self,n):
        x=self.year*12+self.month-1+n
        self.year,self.month=divmod(x,12)
        self.month+=1
        self.paint()
    def paint(self):
        for w in self.days.winfo_children():w.destroy()
        self.heading.config(text=f"{self.month:02d} / {self.year}")
        for i,name in enumerate(("Po","Ut","Sr","Če","Pe","Su","Ne")):
            tk.Label(self.days,text=name,width=4,bg="#f5f7fa",fg="#617184").grid(row=0,column=i)
        first,last=monthrange(self.year,self.month)
        for day in range(1,last+1):
            idx=first+day-1
            current=date(self.year,self.month,day)
            bg="#dceafa" if current==date.today() else "#ffffff"
            tk.Button(self.days,text=str(day),width=3,bg=bg,relief="flat",
                      command=lambda d=current:self.choose(d)).grid(row=1+idx//7,column=idx%7,padx=2,pady=2)
    def choose(self,d):
        self.callback(d)
        self.destroy()

class ShiftPanel(tk.Frame):
    def __init__(self,master,app,n):
        super().__init__(master,bg="white",highlightbackground="#dce3ed",highlightthickness=1)
        self.app,self.n=app,n
        self.loading=False
        self.employee=tk.StringVar()
        self.credit=tk.StringVar()
        self.euro=tk.StringVar()
        self.quantities={v:tk.StringVar() for v in DENOMS}
        self.row_amounts={v:tk.StringVar(value="0,00") for v in DENOMS}
        self.cash_label=tk.StringVar(value="0,00 KM")
        self.delivered_label=tk.StringVar(value="0,00 KM")
        self.card_label=tk.StringVar(value="0,00 KM")
        self.remote_label=tk.StringVar(value="")
        self.last_local_edit=0
        self.pending_remote=None
        self._build()
        for var in list(self.quantities.values())+[self.credit,self.euro]:
            var.trace_add("write",self.changed)
        # Employee typing is deliberately NOT stored as a new employee.
        self.employee.trace_add("write",self.changed)
    def _build(self):
        top=tk.Frame(self,bg="#193451",height=36)
        top.pack(fill="x")
        tk.Label(top,text=f"SMJENA {self.n}",bg="#193451",fg="white",font=("Segoe UI",12,"bold")).pack(pady=7)
        worker=tk.Frame(self,bg="white",padx=8,pady=6)
        worker.pack(fill="x")
        tk.Label(worker,text="RADNIK",bg="white",font=("Segoe UI",9,"bold")).pack(anchor="w")
        wr=tk.Frame(worker,bg="white")
        wr.pack(fill="x")
        self.combo=ttk.Combobox(wr,textvariable=self.employee,font=("Segoe UI",9))
        self.combo.pack(side="left",fill="x",expand=True)
        self.combo.bind("<<ComboboxSelected>>",lambda e:self.save_employee())
        ttk.Button(wr,text="+",width=3,command=self.save_employee).pack(side="left",padx=(4,0))
        tbl=tk.Frame(self,bg="white",padx=8)
        tbl.pack(fill="both",expand=True)
        tbl.grid_columnconfigure(0,weight=1)
        tbl.grid_columnconfigure(1,weight=1)
        tbl.grid_columnconfigure(2,weight=1)
        for j,label in enumerate(("NOVAC","KOM","UKUPNO")):
            tk.Label(tbl,text=label,bg="#e8eef6",fg="#1d344d",font=("Segoe UI",9,"bold"),pady=4).grid(row=0,column=j,sticky="ew")
        for i,d in enumerate(DENOMS,1):
            tk.Label(tbl,text=d.replace(".",","),bg="white",font=("Segoe UI",9)).grid(row=i,column=0,sticky="ew",pady=1)
            entry=ttk.Entry(tbl,textvariable=self.quantities[d],justify="center",font=("Segoe UI",9),width=6)
            entry.grid(row=i,column=1,sticky="ew",padx=3,pady=1)
            tk.Label(tbl,textvariable=self.row_amounts[d],bg="white",font=("Segoe UI",9),anchor="e").grid(row=i,column=2,sticky="ew",pady=1)
        foot=tk.Frame(self,bg="#f5f8fc",padx=8,pady=7)
        foot.pack(fill="x",side="bottom")
        self.summary(foot,"KM KEŠ",self.cash_label)
        self.inputline(foot,"EURO",self.euro)
        self.summary(foot,"TESLIM (KM + EUR)",self.delivered_label,True)
        self.inputline(foot,"KREDIT KART",self.credit)
        self.summary(foot,"KART TOPLAM",self.card_label)
        tk.Label(foot,textvariable=self.remote_label,bg="#f5f8fc",fg="#9b4c20",wraplength=230,font=("Segoe UI",8)).pack(anchor="w")
        ttk.Button(foot,text="SAČUVAJ",command=self.approve_remote).pack(fill="x",pady=(3,0))
    def summary(self,parent,label,var,strong=False):
        row=tk.Frame(parent,bg="#dce9f7" if strong else "#f5f8fc",pady=2)
        row.pack(fill="x",pady=1)
        tk.Label(row,text=label,bg=row["bg"],font=("Segoe UI",9,"bold" if strong else "normal")).pack(side="left")
        tk.Label(row,textvariable=var,bg=row["bg"],font=("Segoe UI",10,"bold")).pack(side="right")
    def inputline(self,parent,label,var):
        row=tk.Frame(parent,bg="#f5f8fc",pady=2)
        row.pack(fill="x")
        tk.Label(row,text=label,bg="#f5f8fc",font=("Segoe UI",9)).pack(side="left")
        ttk.Entry(row,textvariable=var,justify="right",font=("Segoe UI",9),width=11).pack(side="right")
    def load(self):
        self.loading=True
        self.pending_remote=None
        d=self.app.selected.isoformat()
        r=self.app.db.execute("SELECT employee,credit,euros,remote_override FROM shifts WHERE business_date=? AND shift=?",(d,self.n)).fetchone()
        self.employee.set(r[0] if r else "")
        self.credit.set(r[1] if r else "")
        self.euro.set(r[2] if r else "")
        self.remote_label.set(("Telefon: "+r[3]+" KM (farklı)") if r and r[3] else "")
        quantities=dict(self.app.db.execute("SELECT denomination,quantity FROM cash_counts WHERE business_date=? AND shift=?",(d,self.n)))
        for den in DENOMS:self.quantities[den].set(quantities.get(den,""))
        self.loading=False
        self.recalculate()
    def recalculate(self):
        cash=Decimal(0)
        for den,var in self.quantities.items():
            q=number(var.get())
            value=number(den)*q
            cash+=value
            self.row_amounts[den].set(fmt(value))
        self.cash_label.set(fmt(cash)+" KM")
        self.delivered_label.set(fmt(cash+number(self.euro.get())*RATE)+" KM")
        self.card_label.set(fmt(number(self.credit.get()))+" KM")
    def changed(self,*_):
        if self.loading:return
        self.recalculate()
        self.last_local_edit=datetime.now().timestamp()
        self.save()
    def approve_remote(self):
        if not self.pending_remote:
            messagebox.showinfo("Bilgi","Önce merkezden vardiya kaydı alınmalı.",parent=self)
            return
        remote=self.pending_remote
        if not messagebox.askyesno("Teslim Onayı",
            "PC sayım tutarı merkezin mevcut teslim tutarının yerine yazılacak. Devam edilsin mi?",parent=self):
            return
        with self.app.db:
            self.app.db.execute("""INSERT INTO shifts(business_date,shift,updated_at,synced_total,remote_revision,remote_id)
                VALUES(?,?,?,?,?,?) ON CONFLICT(business_date,shift) DO UPDATE SET
                synced_total=excluded.synced_total,remote_revision=excluded.remote_revision,
                remote_id=excluded.remote_id""",
                (self.app.selected.isoformat(),self.n,datetime.now().isoformat(timespec="seconds"),
                str(remote.get("delivered_cash") or "0"),int(remote.get("revision") or 0),str(remote.get("id") or "")))
        self.last_local_edit=datetime.now().timestamp()
        self.pending_remote=None
        self.remote_label.set("Onaylandı • merkeze gönderiliyor")
    def save_employee(self):
        name=self.employee.get().strip()
        if not name:return
        self.app.db.execute("INSERT OR IGNORE INTO employees(name) VALUES(?)",(name,))
        self.app.db.commit()
        self.app.refresh_workers()
        self.save()
    def save(self):
        if self.loading:return
        d=self.app.selected.isoformat()
        name=self.employee.get().strip()
        with self.app.db:
            self.app.db.execute("""INSERT INTO shifts(business_date,shift,employee,credit,euros,updated_at)
            VALUES(?,?,?,?,?,?) ON CONFLICT(business_date,shift) DO UPDATE SET
            employee=excluded.employee,credit=excluded.credit,euros=excluded.euros,updated_at=excluded.updated_at""",
            (d,self.n,name,self.credit.get(),self.euro.get(),datetime.now().isoformat(timespec="seconds")))
            for den,var in self.quantities.items():
                self.app.db.execute("""INSERT INTO cash_counts(business_date,shift,denomination,quantity)
                VALUES(?,?,?,?) ON CONFLICT(business_date,shift,denomination) DO UPDATE SET quantity=excluded.quantity""",
                (d,self.n,den,var.get()))

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("SS OIL | Vardiya Kasa Sayımı")
        self.geometry("1030x650")
        self.minsize(790,510)
        self.configure(bg="#eef2f7")
        self.db=database()
        self.selected=date.today()
        self._build()
        self.refresh_workers()
        self.load()
        self.protocol("WM_DELETE_WINDOW",self.close)
        self.sync_running=False
        self.after(1200,self.poll_sync)
    def _build(self):
        st=ttk.Style(self)
        st.theme_use("clam")
        st.configure("TEntry",padding=2)
        head=tk.Frame(self,bg="#eef2f7",padx=10,pady=7)
        head.pack(fill="x")
        tk.Label(head,text="SS OIL  |  SMJENE",bg="#eef2f7",fg="#18344f",font=("Segoe UI",15,"bold")).pack(side="left")
        self.date_label=tk.StringVar()
        ttk.Button(head,text="◀",width=3,command=lambda:self.move_day(-1)).pack(side="left",padx=(18,3))
        ttk.Button(head,textvariable=self.date_label,command=self.pick_date).pack(side="left")
        ttk.Button(head,text="▶",width=3,command=lambda:self.move_day(1)).pack(side="left",padx=3)
        ttk.Button(head,text="DANAS",command=lambda:self.set_date(date.today())).pack(side="left",padx=5)
        ttk.Button(head,text="RADNICI",command=self.manage_workers).pack(side="left",padx=5)
        self.status=tk.StringVar(value="8767 bağlantısı kontrol ediliyor")
        ttk.Button(head,text="MERKEZ 8767",command=self.server_settings).pack(side="right",padx=(7,0))
        tk.Label(head,textvariable=self.status,bg="#eef2f7",fg="#63758b",font=("Segoe UI",8)).pack(side="right")
        content=tk.Frame(self,bg="#eef2f7",padx=8,pady=4)
        content.pack(fill="both",expand=True)
        for i in range(3):content.grid_columnconfigure(i,weight=1,uniform="panels")
        content.grid_rowconfigure(0,weight=1)
        self.panels=[]
        for i in range(3):
            p=ShiftPanel(content,self,i+1)
            p.grid(row=0,column=i,sticky="nsew",padx=3)
            self.panels.append(p)
        self.bind("<Control-s>",lambda e:self.save_all())
    def manage_workers(self):
        dialog=tk.Toplevel(self)
        dialog.title("Radnici — izbriši pogrešne unose")
        dialog.geometry("320x350")
        dialog.transient(self)
        tk.Label(dialog,text="Odaberi pogrešno ime i izbriši ga:",font=("Segoe UI",10)).pack(padx=12,pady=10)
        names=tk.Listbox(dialog,font=("Segoe UI",10))
        names.pack(fill="both",expand=True,padx=12,pady=6)
        def refresh():
            names.delete(0,"end")
            for row in self.db.execute("SELECT name FROM employees ORDER BY name COLLATE NOCASE"):
                names.insert("end",row[0])
        def remove():
            chosen=names.curselection()
            if not chosen:return
            name=names.get(chosen[0])
            if not messagebox.askyesno("Potvrda",f"Izbrisati radnika iz liste: {name}?",parent=dialog):return
            with self.db:self.db.execute("DELETE FROM employees WHERE name=?",(name,))
            self.refresh_workers()
            refresh()
        ttk.Button(dialog,text="IZBRIŠI ODABRANO IME",command=remove).pack(pady=9)
        refresh()
    def refresh_workers(self):
        names=[r[0] for r in self.db.execute("SELECT name FROM employees ORDER BY name COLLATE NOCASE")]
        for p in self.panels:p.combo["values"]=names
    def load(self):
        self.date_label.set(self.selected.strftime("%d.%m.%Y")+"  ▾")
        for p in self.panels:p.load()
    def save_all(self):
        for p in self.panels:p.save()
    def set_date(self,d):
        self.save_all()
        self.selected=d
        self.load()
    def move_day(self,n):
        from datetime import timedelta
        self.set_date(self.selected+timedelta(days=n))
    def pick_date(self):
        DatePicker(self,self.selected,self.set_date)
    def server_settings(self):
        win=tk.Toplevel(self)
        win.title("PC Merkez — 8767")
        win.resizable(False,False)
        win.transient(self)
        tk.Label(win,text="Merkez bilgisayar IP adresi",font=("Segoe UI",10,"bold")).pack(padx=16,pady=(14,4))
        current=self.db.execute("SELECT value FROM settings WHERE key='server_host'").fetchone()
        host=tk.StringVar(value=current[0] if current else "127.0.0.1")
        ttk.Entry(win,textvariable=host,width=28).pack(padx=16,pady=5)
        tk.Label(win,text="Örnek: 192.168.100.10  •  Port: 8767").pack(padx=16,pady=3)
        def save():
            value=host.get().strip()
            if not value or any(c in value for c in '/ ?#@'):
                messagebox.showerror("Hata","Yalnızca IP veya bilgisayar adı girin.",parent=win)
                return
            with self.db:
                self.db.execute("INSERT INTO settings(key,value) VALUES('server_host',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(value,))
            win.destroy()
            self.status.set("8767 bağlantısı kontrol ediliyor")
        ttk.Button(win,text="KAYDET",command=save).pack(pady=(5,14))
        win.grab_set()
    def poll_sync(self):
        if not self.winfo_exists():return
        if not self.sync_running:
            host=self.db.execute("SELECT value FROM settings WHERE key='server_host'").fetchone()
            host=host[0] if host else "127.0.0.1"
            business_date=self.selected.isoformat()
            snapshot=[]
            for panel in self.panels:
                r=self.db.execute("SELECT remote_revision,remote_id,synced_total,remote_override FROM shifts WHERE business_date=? AND shift=?",(business_date,panel.n)).fetchone()
                local_total=panel.delivered_label.get().split()[0].replace(",",".")
                qty_present=any(x.get().strip() for x in panel.quantities.values()) or bool(panel.euro.get().strip())
                snapshot.append(dict(shift=panel.n,total=local_total,employee=panel.employee.get().strip(),
                                     local_edit=panel.last_local_edit,has_count=qty_present,
                                     remote_revision=r[0] if r else -1,remote_id=r[1] if r else '',
                                     synced_total=r[2] if r else ''))
            self.sync_running=True
            threading.Thread(target=self._sync_thread,args=(host,business_date,snapshot),daemon=True).start()
        self.after(3000,self.poll_sync)
    def _sync_thread(self,host,business_date,snapshot):
        try:
            base=f"http://{host}:8767/vardiya/ssoil_shift_handoffs"
            query=urllib.parse.urlencode({"business_date":"eq."+business_date})
            with urllib.request.urlopen(base+"?"+query,timeout=2.5) as res:
                records=json.load(res)
            if not isinstance(records,list):raise ValueError("Sunucu beklenmeyen yanıt verdi")
            by_shift={int(x.get("shift_number",0)):x for x in records if isinstance(x,dict)}
            results=[]
            for item in snapshot:
                remote=by_shift.get(item["shift"])
                if not remote:
                    results.append((item,"waiting",None))
                    continue
                revision=int(remote.get("revision") or 0)
                remote_total=str(remote.get("delivered_cash") or "0")
                local_total=item["total"]
                baseline=item["synced_total"]
                # Never overwrite phone data without an established common baseline.
                if not baseline:
                    results.append((item,"baseline",remote))
                elif number(remote_total)!=number(baseline) and number(local_total)!=number(baseline):
                    results.append((item,"conflict",remote))
                elif number(remote_total)!=number(baseline):
                    results.append((item,"remote",remote))
                elif item["has_count"] and number(local_total)!=number(baseline):
                    # Guard with revision and id. Do not change snapshots or expected_cash.
                    expected=number(remote.get("expected_cash") or "0")
                    patch={"delivered_cash":float(number(local_total)),
                           "difference":float(number(local_total)-expected),
                           "_expected_revision":revision}
                    uri=base+"?"+urllib.parse.urlencode({"id":"eq."+str(remote["id"])})
                    req=urllib.request.Request(uri,data=json.dumps(patch).encode("utf-8"),
                            headers={"Content-Type":"application/json"},method="PATCH")
                    with urllib.request.urlopen(req,timeout=3) as res:
                        updated=json.load(res)
                    if not updated:raise RuntimeError("Merkez güncelleme onaylamadı")
                    results.append((item,"sent",updated[0]))
                else:
                    results.append((item,"ok",remote))
            self.after(0,lambda:self._apply_sync(business_date,results,None))
        except Exception as e:
            msg=str(e)[:110]
            try:self.after(0,lambda:self._apply_sync(business_date,[],msg))
            except RuntimeError:pass
    def _apply_sync(self,business_date,results,error):
        self.sync_running=False
        if error:
            self.status.set("8767 erişilemiyor: "+error[:42])
            return
        if self.selected.isoformat()!=business_date:return
        self.status.set("8767 bağlı • 3 sn")
        for item,state,remote in results:
            panel=self.panels[item["shift"]-1]
            if panel.last_local_edit!=item["local_edit"]:
                continue
            if state=="waiting":
                panel.remote_label.set("Merkezde vardiya devri henüz yok")
                continue
            if state=="conflict":
                panel.pending_remote=remote
                panel.remote_label.set("UYARI: Telefon ve PC farklı! Telefon: "+fmt(number(remote.get("delivered_cash")))+" KM")
                continue
            if not remote:continue
            remote_total=str(remote.get("delivered_cash") or "0")
            if state=="baseline":
                # First contact: only initialize baseline if no local counts exist.
                if item["has_count"] and number(item["total"])!=number(remote_total):
                    panel.pending_remote=remote
                    panel.remote_label.set("İlk eşleştirme: Telefon "+fmt(number(remote_total))+" KM; PC sayımı farklı. Üzerine yazılmadı.")
                    continue
            if state=="remote":
                panel.remote_label.set("Telefondan değişti: "+fmt(number(remote_total))+" KM (banknotlar değişmedi)")
            elif state=="sent":
                panel.remote_label.set("Teslim tutarı merkeze gönderildi")
            else:
                panel.remote_label.set("")
            with self.db:
                self.db.execute("""INSERT INTO shifts(business_date,shift,updated_at,remote_revision,remote_id,synced_total,remote_override)
                VALUES(?,?,?,?,?,?,?) ON CONFLICT(business_date,shift) DO UPDATE SET
                remote_revision=excluded.remote_revision,remote_id=excluded.remote_id,
                synced_total=excluded.synced_total,remote_override=excluded.remote_override""",
                (business_date,item["shift"],datetime.now().isoformat(timespec="seconds"),
                 int(remote.get("revision") or 0),str(remote.get("id") or ""),
                 remote_total,remote_total if state=="remote" else ""))
    def close(self):
        self.save_all()
        self.db.close()
        self.destroy()
if __name__=="__main__":
    App().mainloop()
